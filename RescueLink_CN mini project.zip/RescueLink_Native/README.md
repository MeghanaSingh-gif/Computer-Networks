# RescueLink — same app, with an edge gateway

This version keeps the existing SwiftUI ambulance UI and hospital dashboard. The iOS app connects to port **5001**, the edge gateway. The hospital server remains on port **8000**. The app automatically migrates an older saved localhost URL from port 5000 to port 5001.

Educational prototype only. Use fictional patient information; this is not a clinically validated system.

## Run it on your Mac (the simple old workflow)

### 1. Start the backend and local edge gateway

Open the `RescueLink_Native` folder in Visual Studio Code. Open Terminal and type these commands **one at a time**, pressing Enter after each:

```bash
cd backend
python3 app.py
```

That's it. Keep this Terminal window open. This single command starts both services:

- Hospital dashboard/server: `http://127.0.0.1:8000`
- Edge gateway used by the iOS app: `http://127.0.0.1:5001`
- Gateway status check: `http://127.0.0.1:5001/health` (returns gateway JSON, not the hospital dashboard)

Open `http://127.0.0.1:8000` in your browser for the hospital dashboard.

### 2. Open the iOS app

In Finder, open `ios` and double-click **`RescueLink.xcodeproj`**. Select an iPhone simulator in Xcode and press **Run ▶**. You do not need to create a project or add files.

The app's default gateway URL is `http://127.0.0.1:5001`. If you previously ran an older build in the same simulator, this version automatically migrates the saved localhost URL from port 5000 to port 5001. In the Connection tab, confirm it shows port 5001.

### 3. Test

1. Submit a fictional patient update in the iOS simulator.
2. Check that the case appears on the hospital dashboard.
3. Mark it reviewed and send a reply from the hospital dashboard.
4. Check the Hospital replies tab in the iOS app.

## Run the edge gateway on a Raspberry Pi later

The Mac demo above runs the hospital server and edge gateway together so it is easy to test. For the real architecture demonstration, the hospital server stays on a computer reachable over the internet, and the Pi runs only the gateway.

On the Pi, copy the `backend` folder. Install Python 3, then run:

```bash
cd backend
HOSPITAL_URL=http://HOSPITAL_SERVER_IP:8000 python3 edge_gateway.py
```

Replace `HOSPITAL_SERVER_IP` with the actual reachable IP/hostname of the computer running the hospital server. Configure the Pi's Wi-Fi access point separately; the gateway script does not configure Wi-Fi or firewall rules.

For an iPhone connected to the Pi's Wi-Fi, set the gateway URL in the app's Connection tab to `http://RASPBERRY_PI_IP:5000`, replacing `RASPBERRY_PI_IP` with the Pi's actual local IP.

## What the edge gateway does

- Relays app requests to the existing hospital server when it is reachable.
- Stores ambulance message submissions in a persistent SQLite queue if the hospital server is unreachable, and retries them periodically.
- Returns an error to the app while the upstream is unavailable, so the app keeps its own outbox pending too.
- Uses message IDs and the existing backend's duplicate protection to avoid creating duplicate cases when a queued message is retried.

Limitations: if the ambulance has no path to the gateway, the message stays in the phone's local outbox until the app can reach a gateway. A gateway cannot provide connectivity where no network path exists. This is a demo, not a secure production deployment; add authentication and TLS before use outside a controlled lab.

## Requirements

- Python 3.10+ (standard library only)
- Xcode for the iOS simulator
- No `pip install` step is required


### Gateway port
RescueLink uses port `5001` by default because macOS may already use port `5000`. Start normally with `cd backend` and `python3 app.py`; no environment variable is needed. The iOS Simulator default URL is `http://127.0.0.1:5001`.

## Edge relay demo (Mac/simulator)

1. Start the backend as usual from `backend`: `python3 app.py`.
2. Run the iOS app in the simulator. Its default gateway URL is `http://127.0.0.1:5001`.
3. In Connection, enable **Simulate direct connection outage**. New messages stay in the iPhone simulator's local outbox.
4. Enable **Send queued messages through edge gateway**. The app attempts to send pending messages to the configured gateway URL even while the direct-outage simulation is enabled. With the default simulator URL, this uses the gateway running on the Mac, which forwards to the local hospital server.
5. Refresh the hospital dashboard. Confirm the message appears and the Outbox marks it delivered only after the server acknowledgement.

## Connecting a physical iPhone to a Raspberry Pi gateway

The simulator demo above exercises the gateway process on the Mac; it does not by itself prove a physical Raspberry Pi Wi-Fi hop. For that test, run `backend/edge_gateway.py` on the Pi, configure `HOSPITAL_URL` to the reachable hospital server URL, and ensure the Pi has a Wi-Fi access point/local network reachable by the iPhone. In the app's Connection screen set the gateway URL to `http://<PI-LAN-IP>:5001` (replace with the Pi's actual LAN IP), then connect the iPhone to that Wi-Fi. The Pi also needs an upstream path to the hospital server; if the upstream is unreachable, the gateway durably queues messages and retries. This is an educational prototype, not for clinical use.
