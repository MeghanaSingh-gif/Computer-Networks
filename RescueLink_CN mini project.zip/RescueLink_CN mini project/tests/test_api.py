import json, tempfile, unittest, threading, urllib.request, urllib.error, sys
from pathlib import Path
from http.server import ThreadingHTTPServer
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'backend'))
import app as server

class RescueLinkAPITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(); server.DB_PATH = Path(cls.temp.name) / 'test.sqlite3'
        cls.httpd = ThreadingHTTPServer(('127.0.0.1',0), server.Handler)
        cls.port = cls.httpd.server_address[1]
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True); cls.thread.start()
        cls.base = f'http://127.0.0.1:{cls.port}'
    @classmethod
    def tearDownClass(cls): cls.httpd.shutdown(); cls.httpd.server_close(); cls.temp.cleanup()
    def payload(self, ident='msg-001'):
        return {'id':ident,'kind':'Emergency alert','priority':'CRITICAL','ambulanceId':'AMB-07','patientRef':'DEMO-CASE','payload':{'situation':'Fictional test alert'},'createdAt':'2026-10-17T12:00:00Z'}
    def call(self, path, body=None):
        data=None if body is None else json.dumps(body).encode()
        req=urllib.request.Request(self.base+path,data=data,headers={'Content-Type':'application/json'})
        try:
            with urllib.request.urlopen(req) as response: return response.status,json.loads(response.read())
        except urllib.error.HTTPError as e: return e.code,json.loads(e.read())
    def test_ack_after_receive_and_list(self):
        status, ack=self.call('/api/messages',self.payload()); self.assertEqual(status,200); self.assertTrue(ack['ack'])
        _, inbox=self.call('/api/messages'); self.assertTrue(any(m['id']=='msg-001' for m in inbox['messages']))
    def test_duplicate_id_is_idempotent(self):
        self.call('/api/messages',self.payload('dup-1')); _,ack=self.call('/api/messages',self.payload('dup-1'))
        self.assertEqual(ack['status'],'duplicate_already_received'); _,inbox=self.call('/api/messages?priority=CRITICAL')
        self.assertEqual(sum(m['id']=='dup-1' for m in inbox['messages']),1)
    def test_missing_fields_rejected(self):
        status,_=self.call('/api/messages',{'id':'incomplete'}); self.assertEqual(status,400)
    def test_hospital_can_send_response_for_ambulance(self):
        self.call('/api/messages', self.payload('response-source'))
        status, body = self.call('/api/responses', {'id':'reply-001','messageId':'response-source','ambulanceId':'AMB-07','patientRef':'DEMO-CASE','responseType':'Arrival preparation','status':'PREPARE_FOR_ARRIVAL','note':'Receiving team ready at bay 2.'})
        self.assertEqual(status, 200); self.assertTrue(body['ack'])
        _, inbox = self.call('/api/responses?ambulanceId=AMB-07')
        self.assertTrue(any(r['id']=='reply-001' and r['note']=='Receiving team ready at bay 2.' for r in inbox['responses']))


    def test_ambulance_can_reply_inside_same_case_thread(self):
        source = self.payload('thread-source')
        source['payload'] = {'patientName':'Demo Patient','age':'42','gender':'Female','presentingComplaint':'Fictional complaint'}
        self.call('/api/messages', source)
        status, body = self.call('/api/responses', {
            'id':'ambulance-reply-1','messageId':'thread-source','ambulanceId':'AMB-07',
            'patientRef':'DEMO-CASE','responseType':'AMBULANCE_REPLY','status':'AMBULANCE_REPLY',
            'note':'We confirm the information.','senderRole':'AMBULANCE'
        })
        self.assertEqual(status, 200)
        self.assertEqual(body['response']['senderRole'], 'AMBULANCE')
        _, thread = self.call('/api/responses?ambulanceId=AMB-07&caseId=DEMO-CASE')
        self.assertTrue(any(r['id']=='ambulance-reply-1' and r['senderRole']=='AMBULANCE' for r in thread['responses']))
        _, inbox = self.call('/api/messages')
        msg = next(m for m in inbox['messages'] if m['id']=='thread-source')
        self.assertEqual(msg['payload']['patientName'], 'Demo Patient')
        self.assertEqual(msg['payload']['age'], '42')

    def test_priority_filter(self):
        p=self.payload('normal-1'); p['priority']='NORMAL'; self.call('/api/messages',p)
        _,inbox=self.call('/api/messages?priority=NORMAL'); self.assertTrue(all(m['priority']=='NORMAL' for m in inbox['messages']))


    def test_review_is_separate_from_delivery_and_persists(self):
        self.call('/api/messages', self.payload('review-source'))
        _, before = self.call('/api/messages')
        item = next(m for m in before['messages'] if m['id'] == 'review-source')
        self.assertEqual(item['reviewStatus'], 'AWAITING_REVIEW')
        status, ack = self.call('/api/reviews', {'id':'review-event-1','messageId':'review-source','reviewerId':'STAFF-DEMO-1'})
        self.assertEqual(status, 200); self.assertEqual(ack['reviewStatus'], 'REVIEWED')
        _, after = self.call('/api/messages')
        item = next(m for m in after['messages'] if m['id'] == 'review-source')
        self.assertEqual(item['reviewStatus'], 'REVIEWED')
        self.assertEqual(item['reviewerId'], 'STAFF-DEMO-1')
        self.assertTrue(item['reviewedAt'])

    def test_hospital_can_send_clarification_and_preparation_status(self):
        self.call('/api/messages', self.payload('workflow-source'))
        for ident, status_value in [('clarify-1','CLARIFICATION_REQUEST'), ('prep-1','PREPARING')]:
            status, body = self.call('/api/responses', {'id':ident,'messageId':'workflow-source','ambulanceId':'AMB-07','patientRef':'DEMO-CASE','responseType':status_value,'status':status_value,'note':'Fictional test update'})
            self.assertEqual(status, 200); self.assertTrue(body['ack'])
        _, inbox = self.call('/api/responses?ambulanceId=AMB-07')
        self.assertTrue(any(r['id']=='clarify-1' for r in inbox['responses']))
        self.assertTrue(any(r['id']=='prep-1' for r in inbox['responses']))

    def test_response_receipt_is_separate_event(self):
        self.call('/api/messages', self.payload('receipt-source'))
        self.call('/api/responses', {'id':'receipt-reply','messageId':'receipt-source','ambulanceId':'AMB-07','patientRef':'DEMO-CASE','responseType':'General reply','status':'REPLY','note':'Fictional reply'})
        status, receipt = self.call('/api/response-receipts', {'id':'receipt-reply','ambulanceId':'AMB-07'})
        self.assertEqual(status, 200); self.assertTrue(receipt['receivedByAmbulanceAt'])
        _, inbox = self.call('/api/responses?ambulanceId=AMB-07')
        reply = next(r for r in inbox['responses'] if r['id']=='receipt-reply')
        self.assertEqual(reply['receivedByAmbulanceAt'], receipt['receivedByAmbulanceAt'])

if __name__ == '__main__': unittest.main(verbosity=2)
