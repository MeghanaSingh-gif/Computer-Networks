import SwiftUI

@main
struct RescueLinkApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
