import Foundation
import Combine

@MainActor
final class MessageStore: ObservableObject {
    @Published private(set) var messages: [OutboxMessage] = []
    @Published private(set) var hospitalResponses: [HospitalResponse] = []
    @Published var responseStatus = "Waiting for hospital replies."
    // Migrate older simulator installs that saved port 5000. UserDefaults overrides
    // a property's fallback value, so changing only the fallback would not fix those installs.
    private static func initialBackendURL() -> String {
        let key = "backendURL"
        guard let saved = UserDefaults.standard.string(forKey: key), !saved.isEmpty else {
            return "http://127.0.0.1:5001"
        }
        // Keep local simulator installs pointed at the edge gateway, not the
        // hospital server directly. Preserve non-local addresses for Pi/LAN use.
        let localHosts = ["http://127.0.0.1:", "http://localhost:"]
        if localHosts.contains(where: { saved.hasPrefix($0) }) {
            let migrated = saved
                .replacingOccurrences(of: ":5000", with: ":5001")
                .replacingOccurrences(of: ":8000", with: ":5001")
            if migrated != saved {
                UserDefaults.standard.set(migrated, forKey: key)
                return migrated
            }
        }
        return saved
    }

    @Published var backendURL: String = MessageStore.initialBackendURL() {
        didSet { UserDefaults.standard.set(backendURL, forKey: "backendURL") }
    }
    @Published var isSending = false
    @Published var lastStatus = "Messages stay on this device until acknowledged by the hospital server."
    @Published var simulateOutage = false
    @Published var simulateRelay = false {
        didSet {
            // When relay mode is enabled during the simulated direct outage,
            // attempt delivery through the configured edge gateway.
            if simulateRelay && simulateOutage {
                Task { await flushOutbox() }
            }
        }
    }

    private let fileName = "resuelink-outbox.json"
    init() { load() }
    var pendingCount: Int { messages.filter { $0.state != "Delivered" }.count }
    var deliveredCount: Int { messages.filter { $0.state == "Delivered" }.count }

    private var fileURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent(fileName)
    }
    private func load() {
        guard let data = try? Data(contentsOf: fileURL), let decoded = try? JSONDecoder().decode([OutboxMessage].self, from: data) else { return }
        messages = decoded
    }
    private func persist() {
        guard let data = try? JSONEncoder().encode(messages) else { return }
        try? data.write(to: fileURL, options: .atomic)
    }
    func enqueue(kind: MessageKind, priority: MessagePriority, ambulance: String, patientRef: String, payload: [String: String]) {
        let msg = OutboxMessage(id: UUID().uuidString, kind: kind.rawValue, priority: priority.rawValue,
                                ambulanceId: ambulance.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "AMB-07" : ambulance,
                                patientRef: patientRef, payload: payload,
                                createdAt: ISO8601DateFormatter().string(from: Date()), state: "Queued", lastError: nil, deliveredAt: nil, reviewStatus: "AWAITING_REVIEW", reviewedAt: nil, reviewerId: nil)
        messages.insert(msg, at: 0)
        persist()
        lastStatus = "Saved to the on-device outbox. Attempting delivery…"
        Task { await flushOutbox() }
    }
    func flushOutbox() async {
        guard !isSending else { return }
        // Direct-outage mode normally keeps messages on the phone. If the user
        // enables relay mode, still attempt the configured gateway URL: in a real
        // deployment this URL is the Raspberry Pi's LAN address over Wi-Fi.
        guard !simulateOutage || simulateRelay else {
            lastStatus = "Simulated direct outage: message is safely queued on this device. Enable relay mode to try the edge gateway over Wi-Fi."
            return
        }
        if simulateOutage && simulateRelay {
            lastStatus = "Direct path simulated as unavailable. Attempting delivery through the configured edge gateway…"
        }
        guard let base = URL(string: backendURL.trimmingCharacters(in: .whitespacesAndNewlines)), base.scheme != nil else {
            lastStatus = "Backend URL is invalid. Update it in Connection settings."; return
        }
        isSending = true
        defer { isSending = false }
        let candidates = messages.indices.filter { messages[$0].state != "Delivered" }
        for index in candidates {
            var message = messages[index]
            message.state = "Sending"; messages[index] = message; persist()
            do {
                var request = URLRequest(url: base.appendingPathComponent("api/messages"))
                request.httpMethod = "POST"
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                request.timeoutInterval = 8
                request.httpBody = try JSONEncoder().encode(message)
                let (data, response) = try await URLSession.shared.data(for: request)
                guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
                    throw URLError(.badServerResponse)
                }
                let ack = try JSONDecoder().decode(ReceiveAck.self, from: data)
                guard ack.ack && ack.id == message.id else { throw URLError(.cannotParseResponse) }
                message.state = "Delivered"; message.deliveredAt = ack.receivedAt; message.lastError = nil
                lastStatus = simulateOutage && simulateRelay
                    ? "Edge relay path succeeded: hospital server acknowledged \(message.kind.lowercased())."
                    : "Hospital server acknowledged \(message.kind.lowercased())."
            } catch {
                message.state = "Queued"; message.lastError = error.localizedDescription
                lastStatus = "Edge/server delivery failed (\(error.localizedDescription)). Message remains queued on this device; check the gateway URL and Wi-Fi connection."
                messages[index] = message; persist()
                break
            }
            messages[index] = message; persist()
        }
    }

    func refreshHospitalResponses(ambulance: String = "AMB-07") async {
        guard let base = URL(string: backendURL.trimmingCharacters(in: .whitespacesAndNewlines)) else { return }
        await refreshReviewStates(base: base)
        var components = URLComponents(url: base.appendingPathComponent("api/responses"), resolvingAgainstBaseURL: false)
        components?.queryItems = [URLQueryItem(name: "ambulanceId", value: ambulance)]
        guard let url = components?.url else { return }
        do {
            let (data, response) = try await URLSession.shared.data(from: url)
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { throw URLError(.badServerResponse) }
            hospitalResponses = try JSONDecoder().decode(ResponsesEnvelope.self, from: data).responses
            // This receipt means the app fetched and stored the reply, not that a crew member read it.
            for index in hospitalResponses.indices where (hospitalResponses[index].senderRole ?? "HOSPITAL") == "HOSPITAL" && hospitalResponses[index].receivedByAmbulanceAt == nil {
                var receipt = URLRequest(url: base.appendingPathComponent("api/response-receipts"))
                receipt.httpMethod = "POST"
                receipt.setValue("application/json", forHTTPHeaderField: "Content-Type")
                receipt.httpBody = try? JSONSerialization.data(withJSONObject: ["id": hospitalResponses[index].id, "ambulanceId": ambulance])
                if let (receiptData, receiptResponse) = try? await URLSession.shared.data(for: receipt),
                   let http = receiptResponse as? HTTPURLResponse, (200..<300).contains(http.statusCode),
                   let ack = try? JSONDecoder().decode(ResponseReceiptAck.self, from: receiptData), ack.ack {
                    hospitalResponses[index].receivedByAmbulanceAt = ack.receivedByAmbulanceAt
                }
            }
            responseStatus = hospitalResponses.isEmpty ? "No hospital replies yet." : "Updated just now · \(hospitalResponses.count) replies"
        } catch {
            responseStatus = "Cannot fetch replies. Check the backend connection."
        }
    }

    private func refreshReviewStates(base: URL) async {
        guard let url = URL(string: "api/messages?limit=500", relativeTo: base)?.absoluteURL else { return }
        do {
            let (data, response) = try await URLSession.shared.data(from: url)
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { return }
            let remote = try JSONDecoder().decode(MessagesEnvelope.self, from: data).messages
            let states = Dictionary(uniqueKeysWithValues: remote.map { ($0.id, $0) })
            for index in messages.indices {
                if let server = states[messages[index].id] {
                    messages[index].reviewStatus = server.reviewStatus
                    messages[index].reviewedAt = server.reviewedAt
                    messages[index].reviewerId = server.reviewerId
                }
            }
            persist()
        } catch { /* Review state will be refreshed on the next poll. */ }
    }

    func retry() { Task { await flushOutbox() } }
    func clearDelivered() { messages.removeAll { $0.state == "Delivered" }; persist() }
}
