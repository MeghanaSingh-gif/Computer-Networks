import SwiftUI

private struct CaseThreadItem: Identifiable {
    let id: String
    let senderRole: String
    let title: String
    let body: String
    let createdAt: String
    let status: String
}

struct ContentView: View {
    @StateObject private var store = MessageStore()
    @State private var tab = 0
    @State private var ambulanceID = "AMB-07"
    @AppStorage("rl.patientRef") private var patientRef = "CASE-104"
    @State private var selectedKind: MessageKind = .emergencyAlert
    @State private var selectedPriority: MessagePriority = .critical
    @AppStorage("rl.patientName") private var patientName = ""
    @AppStorage("rl.patientAge") private var patientAge = ""
    @AppStorage("rl.patientGender") private var patientGender = ""
    @AppStorage("rl.presentingComplaint") private var presentingComplaint = ""
    @AppStorage("rl.relevantHistory") private var relevantHistory = ""
    @AppStorage("rl.allergies") private var allergies = ""
    @AppStorage("rl.initialAssessment") private var initialAssessment = ""
    @AppStorage("rl.crewNotes") private var crewNotes = ""
    @AppStorage("rl.origin") private var origin = ""
    @AppStorage("rl.destination") private var destination = "Receiving hospital"
    @State private var heartRate = "98"
    @State private var oxygen = "96"
    @State private var systolic = "118"
    @State private var diastolic = "78"
    @State private var respiratoryRate = "16"
    @State private var eta = "8 minutes"
    @State private var note = ""
    @State private var clarificationRequestID = ""
    @State private var caseStatus = "ACTIVE"
    @State private var replyDraft = ""
    @State private var replyMode = "AMBULANCE_REPLY"
    @State private var sendingReply = false
    @State private var showQueuedAlert = false

    var body: some View {
        TabView(selection: $tab) {
            NavigationStack { composeView }.tabItem { Label("Transmit", systemImage: "paperplane.fill") }.tag(0)
            NavigationStack { outboxView }.tabItem { Label("Outbox", systemImage: "tray.full") }.tag(1)
            NavigationStack { connectionView }.tabItem { Label("Connection", systemImage: "antenna.radiowaves.left.and.right") }.tag(2)
            NavigationStack { repliesView }.tabItem { Label("Hospital replies", systemImage: "bubble.left.and.bubble.right") }.tag(3)
        }
        .tint(Color(red: 0.72, green: 0.13, blue: 0.16))
        .task { await store.flushOutbox(); await store.refreshHospitalResponses(ambulance: ambulanceID); while !Task.isCancelled { try? await Task.sleep(for: .seconds(5)); await store.refreshHospitalResponses(ambulance: ambulanceID) } }
    }

    private var composeView: some View {
        Form {
            Section {
                HStack(spacing: 12) {
                    Image(systemName: "cross.case.fill").font(.title2).foregroundStyle(.white).frame(width: 48, height: 48).background(Color(red: 0.72, green: 0.13, blue: 0.16), in: RoundedRectangle(cornerRadius: 13))
                    VStack(alignment: .leading, spacing: 3) {
                        Text("Ambulance communications").font(.headline)
                        Text("Store-and-forward · Demo mode").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Circle().fill(store.simulateOutage ? .orange : .green).frame(width: 9, height: 9)
                }
                .padding(.vertical, 5)
            }
            Section("Unit & case") {
                TextField("Ambulance ID", text: $ambulanceID).textInputAutocapitalization(.characters)
                TextField("Case / patient reference (e.g. CASE-104)", text: $patientRef).textInputAutocapitalization(.characters)
                TextField("Pickup / origin", text: $origin)
                TextField("Destination hospital", text: $destination)
            }
            Section("Patient details") {
                TextField("Patient name (fictional)", text: $patientName)
                    .textContentType(.name)
                HStack {
                    TextField("Age", text: $patientAge).keyboardType(.numberPad).frame(maxWidth: .infinity)
                    Picker("Gender", selection: $patientGender) {
                        Text("Not specified").tag("")
                        Text("Female").tag("Female")
                        Text("Male").tag("Male")
                        Text("Other").tag("Other")
                    }.labelsHidden().frame(maxWidth: .infinity)
                }
                TextField("Presenting complaint / symptoms", text: $presentingComplaint, axis: .vertical).lineLimit(2...4)
                TextField("Relevant medical history", text: $relevantHistory, axis: .vertical).lineLimit(2...3)
                TextField("Allergies (or ‘Unknown’)", text: $allergies)
                TextField("Initial assessment", text: $initialAssessment, axis: .vertical).lineLimit(2...4)
                TextField("Crew notes", text: $crewNotes, axis: .vertical).lineLimit(2...4)
                Text("Patient details are saved on this device and attached to every outgoing case message, including vitals and ETA updates. Use fictional demo details only.").font(.caption).foregroundStyle(.secondary)
            }
            Section("Compose update") {
                Picker("Message type", selection: $selectedKind) { ForEach(MessageKind.allCases) { Text($0.rawValue).tag($0) } }
                Picker("Priority", selection: $selectedPriority) { ForEach(MessagePriority.allCases) { Text($0.label).tag($0) } }
                if selectedKind == .patientVitals {
                    HStack { Text("Heart rate"); Spacer(); TextField("bpm", text: $heartRate).keyboardType(.numberPad).multilineTextAlignment(.trailing).frame(width: 90); Text("bpm").foregroundStyle(.secondary) }
                    HStack { Text("SpO₂"); Spacer(); TextField("%", text: $oxygen).keyboardType(.numberPad).multilineTextAlignment(.trailing).frame(width: 90); Text("%").foregroundStyle(.secondary) }
                    HStack { Text("Systolic BP"); Spacer(); TextField("mmHg", text: $systolic).keyboardType(.numberPad).multilineTextAlignment(.trailing).frame(width: 90); Text("mmHg").foregroundStyle(.secondary) }
                    HStack { Text("Diastolic BP"); Spacer(); TextField("mmHg", text: $diastolic).keyboardType(.numberPad).multilineTextAlignment(.trailing).frame(width: 90); Text("mmHg").foregroundStyle(.secondary) }
                    HStack { Text("Respiratory rate"); Spacer(); TextField("/min", text: $respiratoryRate).keyboardType(.numberPad).multilineTextAlignment(.trailing).frame(width: 90); Text("/min").foregroundStyle(.secondary) }
                } else if selectedKind == .arrivalUpdate {
                    TextField("Estimated time of arrival", text: $eta)
                } else if selectedKind == .clarificationResponse {
                    TextField("Clarification request ID", text: $clarificationRequestID).textInputAutocapitalization(.never)
                    TextField("Answer to hospital question", text: $note, axis: .vertical).lineLimit(2...5)
                } else if selectedKind == .caseStatusUpdate {
                    Picker("Case status", selection: $caseStatus) { Text("Active").tag("ACTIVE"); Text("Arrived").tag("ARRIVED"); Text("Handover complete").tag("HANDED_OVER") }
                    TextField("Optional note", text: $note, axis: .vertical).lineLimit(2...5)
                } else {
                    TextField(selectedKind == .emergencyAlert ? "Situation / symptoms" : "Handover note", text: $note, axis: .vertical).lineLimit(2...5)
                }
                Button { sendCurrent() } label: {
                    HStack { Spacer(); if store.isSending { ProgressView().tint(.white) }; Text("Save & transmit").fontWeight(.semibold); Spacer() }
                }.listRowBackground(Color(red: 0.72, green: 0.13, blue: 0.16)).foregroundStyle(.white)
            }
            Section {
                Label(store.lastStatus, systemImage: store.pendingCount > 0 ? "clock.arrow.circlepath" : "checkmark.circle").font(.footnote).foregroundStyle(.secondary)
                HStack { Label("Queued", systemImage: "tray.full"); Spacer(); Text("\(store.pendingCount)").fontWeight(.semibold) }
                HStack { Label("Acknowledged", systemImage: "checkmark.seal"); Spacer(); Text("\(store.deliveredCount)").fontWeight(.semibold) }
            } header: { Text("Delivery status") }
        }
        .navigationTitle("RescueLink")
        .alert("Update saved", isPresented: $showQueuedAlert) {
            Button("View outbox") { tab = 1 }
            Button("OK", role: .cancel) { }
        } message: {
            Text("Your update has been saved on this device. Check Delivery status below or open Outbox to see whether the hospital server acknowledged it.")
        }
        .toolbar { ToolbarItem(placement: .topBarTrailing) { Button { tab = 1 } label: { Image(systemName: "tray.full") } } }
    }

    private var outboxView: some View {
        List {
            Section { Text("Only messages acknowledged by the backend are marked Delivered. Unacknowledged messages remain stored locally.").font(.footnote).foregroundStyle(.secondary) }
            if store.messages.isEmpty { ContentUnavailableView("Outbox is empty", systemImage: "tray", description: Text("Create an update in Transmit.")) }
            ForEach(store.messages) { message in
                VStack(alignment: .leading, spacing: 7) {
                    HStack { Text(message.kind).font(.headline); Spacer(); priorityBadge(message.priority) }
                    HStack(spacing: 6) { Image(systemName: message.state == "Delivered" ? "checkmark.circle.fill" : "clock"); Text(message.state); Text("· \(message.ambulanceId)") }.font(.caption).foregroundColor(message.state == "Delivered" ? Color.green : Color.secondary)
                    if message.state == "Delivered" { Label(message.reviewStatus == "REVIEWED" ? "Reviewed by hospital" : "Awaiting hospital review", systemImage: message.reviewStatus == "REVIEWED" ? "person.crop.circle.badge.checkmark" : "hourglass").font(.caption).foregroundStyle(message.reviewStatus == "REVIEWED" ? .green : .orange); if let who = message.reviewerId, let when = message.reviewedAt { Text("\(who) · \(when)").font(.caption2).foregroundStyle(.secondary) } }
                    Text(message.createdAt).font(.caption2).foregroundStyle(.tertiary)
                    if let error = message.lastError, !error.isEmpty { Text(error).font(.caption).foregroundStyle(.orange).lineLimit(2) }
                }.padding(.vertical, 4)
            }
            if !store.messages.isEmpty { Button("Retry pending messages") { store.retry() }; Button("Clear acknowledged messages", role: .destructive) { store.clearDelivered() } }
        }.navigationTitle("Message outbox")
    }

    private var repliesView: some View {
        List {
            Section {
                Label(store.responseStatus, systemImage: "arrow.triangle.2.circlepath").font(.footnote).foregroundStyle(.secondary)
                Text("This is the case conversation. Hospital messages and your replies stay grouped under the same case reference.").font(.caption).foregroundStyle(.secondary)
            }
            Section("Case conversation") {
                let caseRefs = Array(Set(store.messages.map { $0.patientRef } + [patientRef])).filter { !$0.isEmpty }.sorted()
                Picker("Case", selection: $patientRef) {
                    ForEach(caseRefs, id: \.self) { ref in Text(ref).tag(ref) }
                }
                HStack {
                    Label(patientRef.isEmpty ? "No case selected" : patientRef, systemImage: "cross.case")
                    Spacer()
                    Text("\(ambulanceID)").font(.caption).foregroundStyle(.secondary)
                }
                let thread = caseThreadItems
                if thread.isEmpty {
                    ContentUnavailableView("No messages in this case yet", systemImage: "bubble.left.and.bubble.right", description: Text("Send a pre-alert from Transmit, or wait for a hospital response linked to this case."))
                } else {
                    ForEach(thread) { item in
                        HStack(alignment: .top, spacing: 10) {
                            Image(systemName: item.senderRole == "AMBULANCE" ? "paperplane.fill" : "building.2.fill")
                                .foregroundStyle(item.senderRole == "AMBULANCE" ? Color.red : Color.blue)
                                .frame(width: 30, height: 30)
                                .background((item.senderRole == "AMBULANCE" ? Color.red : Color.blue).opacity(0.1), in: Circle())
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text(item.senderRole == "AMBULANCE" ? "Ambulance" : "Hospital").font(.caption.bold())
                                    Spacer()
                                    Text(item.title).font(.caption2.bold()).foregroundStyle(.secondary)
                                }
                                Text(item.body).font(.body)
                                Text(item.createdAt).font(.caption2).foregroundStyle(.secondary)
                                Label(item.status, systemImage: item.status.localizedCaseInsensitiveContains("queue") ? "clock" : "checkmark.circle.fill")
                                    .font(.caption2).foregroundStyle(item.status.localizedCaseInsensitiveContains("queue") ? .orange : .green)
                            }
                        }.padding(.vertical, 5)
                    }
                }
            }
            Section("Reply to hospital") {
                Picker("Message type", selection: $replyMode) {
                    Text("General reply").tag("AMBULANCE_REPLY")
                    Text("Answer clarification").tag("CLARIFICATION_RESPONSE")
                }.pickerStyle(.segmented)
                TextField("Type your response…", text: $replyDraft, axis: .vertical).lineLimit(3...6)
                Button {
                    Task { await sendAmbulanceReply() }
                } label: {
                    HStack { Spacer(); if sendingReply { ProgressView().tint(.white) }; Text("Send reply in this case").fontWeight(.semibold); Spacer() }
                }
                .disabled(sendingReply || replyDraft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || store.messages.first(where: { $0.patientRef == patientRef }) == nil)
                .listRowBackground(Color(red: 0.72, green: 0.13, blue: 0.16)).foregroundStyle(.white)
                Text("The reply is linked to the original case and will appear in the hospital's case conversation after synchronization.").font(.caption).foregroundStyle(.secondary)
            }
            Section {
                Button("Refresh case conversation") { Task { await store.refreshHospitalResponses(ambulance: ambulanceID) } }
            }
        }
        .navigationTitle("Case conversation")
        .toolbar { ToolbarItem(placement: .topBarTrailing) { Button { Task { await store.refreshHospitalResponses(ambulance: ambulanceID) } } label: { Image(systemName: "arrow.clockwise") } } }
    }

    @MainActor private func sendAmbulanceReply() async {
        let text = replyDraft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, let related = store.messages.first(where: { $0.patientRef == patientRef }) else { return }
        guard let base = URL(string: store.backendURL.trimmingCharacters(in: .whitespacesAndNewlines)) else { return }
        sendingReply = true
        defer { sendingReply = false }
        var request = URLRequest(url: base.appendingPathComponent("api/responses"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body: [String: String] = [
            "id": UUID().uuidString,
            "messageId": related.id,
            "ambulanceId": ambulanceID,
            "patientRef": patientRef,
            "responseType": replyMode,
            "status": replyMode,
            "note": text,
            "senderRole": "AMBULANCE"
        ]
        do {
            request.httpBody = try JSONEncoder().encode(body)
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { throw URLError(.badServerResponse) }
            _ = try JSONDecoder().decode(ResponsePostEnvelope.self, from: data)
            replyDraft = ""
            await store.refreshHospitalResponses(ambulance: ambulanceID)
        } catch {
            store.lastStatus = "Could not send reply: \(error.localizedDescription)"
        }
    }

    private var caseThreadItems: [CaseThreadItem] {
        let outbound = store.messages.filter { $0.patientRef == patientRef }.map { message in
            let details = [message.payload["situation"], message.payload["patientName"].map { "Patient: \($0)" }, message.payload["age"].map { "Age: \($0)" }, message.payload["presentingComplaint"], message.payload["initialAssessment"].map { "Assessment: \($0)" }, message.payload["crewNotes"].map { "Crew notes: \($0)" }, message.payload["heartRateBpm"].map { "HR \($0) bpm" }, message.payload["spo2Percent"].map { "SpO₂ \($0)%" }].compactMap { $0 }.filter { !$0.isEmpty }.joined(separator: " · ")
            return CaseThreadItem(id: "out-\(message.id)", senderRole: "AMBULANCE", title: message.kind, body: details.isEmpty ? "Ambulance update" : details, createdAt: message.createdAt, status: message.state == "Delivered" ? "Delivered to hospital" : "Queued on device")
        }
        let inbound = store.hospitalResponses.filter { ($0.patientRef ?? "") == patientRef }.map { reply in
            let from = reply.senderRole ?? "HOSPITAL"
            let status = from == "HOSPITAL" ? (reply.receivedByAmbulanceAt == nil ? "Receipt pending" : "Received by ambulance app") : "Sent to hospital"
            return CaseThreadItem(id: "reply-\(reply.id)", senderRole: from, title: reply.responseType.replacingOccurrences(of: "_", with: " "), body: reply.note, createdAt: reply.createdAt, status: status)
        }
        return (outbound + inbound).sorted { $0.createdAt < $1.createdAt }
    }

    private var connectionView: some View {
        Form {
            Section("Backend endpoint") {
                TextField("http://127.0.0.1:5001", text: $store.backendURL).keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                Text("Use the edge gateway URL. Simulator: http://127.0.0.1:5001. Physical iPhone: use your Mac or Raspberry Pi LAN IP and gateway port 5001.").font(.caption).foregroundStyle(.secondary)
                Button("Test connection & retry outbox") { store.retry() }
            }
            Section("Network lab controls") {
                Toggle("Simulate direct connection outage", isOn: $store.simulateOutage)
                Toggle("Send queued messages through edge gateway", isOn: $store.simulateRelay).disabled(!store.simulateOutage)
                Text("With direct-outage simulation enabled, turn this on to attempt delivery through the configured edge gateway. For a real Raspberry Pi test, set the gateway URL to the Pi's LAN IP and connect the iPhone to the Pi's Wi-Fi.").font(.caption).foregroundStyle(.secondary)
                if store.simulateOutage && !store.simulateRelay { Label("Messages are queued on this iPhone", systemImage: "wifi.slash").foregroundStyle(.orange) }
                if store.simulateOutage && store.simulateRelay { Label("Trying the configured edge gateway", systemImage: "wifi.router.fill").foregroundStyle(.blue) }
            }
            Section("What the prototype guarantees") {
                Label("Durable local outbox", systemImage: "externaldrive.fill")
                Label("Server acknowledgement after SQLite commit", systemImage: "checkmark.shield")
                Label("Stable message IDs and duplicate suppression", systemImage: "doc.on.doc")
                Label("Retry after manual reconnect", systemImage: "arrow.clockwise")
                Text("This prototype cannot deliver during a total loss of every communication path. Messages wait on the device until the server becomes reachable again.").font(.caption).foregroundStyle(.secondary)
            }
        }.navigationTitle("Connection lab")
    }

    private func sendCurrent() {
        var payload: [String: String] = [:]
        switch selectedKind {
        case .emergencyAlert: payload = ["situation": note.isEmpty ? "Emergency assistance requested" : note]
        case .patientVitals: payload = ["heartRateBpm": heartRate, "spo2Percent": oxygen, "systolicMmHg": systolic, "diastolicMmHg": diastolic, "respiratoryRate": respiratoryRate, "source": "manual", "measuredAt": ISO8601DateFormatter().string(from: Date()), "enteredAt": ISO8601DateFormatter().string(from: Date())]
        case .arrivalUpdate: payload = ["eta": eta]
        case .handoverNote: payload = ["note": note.isEmpty ? "Handover details to follow" : note]
        case .clarificationResponse: payload = ["requestId": clarificationRequestID, "responseText": note, "source": "manual"]
        case .caseStatusUpdate: payload = ["caseStatus": caseStatus, "note": note, "eventAt": ISO8601DateFormatter().string(from: Date())]
        }
        let patientFields: [String: String] = [
            "patientName": patientName.trimmingCharacters(in: .whitespacesAndNewlines),
            "age": patientAge.trimmingCharacters(in: .whitespacesAndNewlines),
            "gender": patientGender,
            "presentingComplaint": presentingComplaint.trimmingCharacters(in: .whitespacesAndNewlines),
            "relevantHistory": relevantHistory.trimmingCharacters(in: .whitespacesAndNewlines),
            "allergies": allergies.trimmingCharacters(in: .whitespacesAndNewlines),
            "initialAssessment": initialAssessment.trimmingCharacters(in: .whitespacesAndNewlines),
            "crewNotes": crewNotes.trimmingCharacters(in: .whitespacesAndNewlines),
            "from": origin.trimmingCharacters(in: .whitespacesAndNewlines),
            "destination": destination.trimmingCharacters(in: .whitespacesAndNewlines),
            "eta": eta.trimmingCharacters(in: .whitespacesAndNewlines)
        ].filter { !$0.value.isEmpty }
        payload.merge(patientFields) { _, new in new }
        store.enqueue(kind: selectedKind, priority: selectedPriority, ambulance: ambulanceID, patientRef: patientRef, payload: payload)
        showQueuedAlert = true
        note = ""
        if selectedKind == .clarificationResponse { clarificationRequestID = "" }
    }
    @ViewBuilder private func priorityBadge(_ value: String) -> some View {
        Text(value).font(.system(size: 10, weight: .bold)).padding(.horizontal, 8).padding(.vertical, 5)
            .background(value == "CRITICAL" ? Color.red.opacity(0.12) : value == "HIGH" ? Color.orange.opacity(0.15) : Color.green.opacity(0.12), in: Capsule())
            .foregroundStyle(value == "CRITICAL" ? .red : value == "HIGH" ? .orange : .green)
    }
}
