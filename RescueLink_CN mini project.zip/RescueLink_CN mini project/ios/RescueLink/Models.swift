import Foundation

enum MessagePriority: String, Codable, CaseIterable, Identifiable {
    case critical = "CRITICAL", high = "HIGH", normal = "NORMAL"
    var id: String { rawValue }
    var label: String { rawValue.capitalized }
}

enum MessageKind: String, Codable, CaseIterable, Identifiable {
    case emergencyAlert = "Emergency alert"
    case patientVitals = "Patient vitals"
    case arrivalUpdate = "ETA update"
    case handoverNote = "Handover note"
    case clarificationResponse = "Clarification response"
    case caseStatusUpdate = "Case status update"
    var id: String { rawValue }
}

struct OutboxMessage: Codable, Identifiable {
    let id: String
    let kind: String
    let priority: String
    let ambulanceId: String
    let patientRef: String
    let payload: [String: String]
    let createdAt: String
    var state: String
    var lastError: String?
    var deliveredAt: String?
    var reviewStatus: String?
    var reviewedAt: String?
    var reviewerId: String?

    enum CodingKeys: String, CodingKey {
        case id, kind, priority, ambulanceId, patientRef, payload, createdAt
        case state, lastError, deliveredAt, reviewStatus, reviewedAt, reviewerId
    }
}

struct ReceiveAck: Decodable {
    let ack: Bool
    let id: String
    let status: String
    let receivedAt: String
}

struct HospitalResponse: Codable, Identifiable {
    let id: String
    let messageId: String
    let ambulanceId: String
    let patientRef: String?
    let responseType: String
    let status: String
    let note: String
    let createdAt: String
    var receivedByAmbulanceAt: String?
    var senderRole: String?
}

struct ServerMessage: Decodable { let id: String; let reviewStatus: String?; let reviewedAt: String?; let reviewerId: String? }
struct MessagesEnvelope: Decodable { let messages: [ServerMessage] }

struct ResponsesEnvelope: Decodable {
    let responses: [HospitalResponse]
}

struct ResponseReceiptAck: Decodable { let ack: Bool; let id: String; let receivedByAmbulanceAt: String }
struct ResponsePostEnvelope: Decodable { let ack: Bool; let response: HospitalResponse }
