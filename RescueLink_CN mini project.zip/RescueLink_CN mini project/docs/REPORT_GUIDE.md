# RescueLink report and demo guide

## Problem statement
Ambulances can experience fluctuating connectivity while travelling, causing delays or failures in transmitting time-sensitive alerts, patient updates, and estimated arrival times. A resilient communication workflow should preserve updates during outages, prioritize critical messages, and confirm delivery when connectivity returns.

## Objectives
1. Demonstrate local store-and-forward when the backend is unavailable.
2. Confirm receipt only after the server commits a message to persistent storage.
3. Prevent duplicate inbox records when the same message is retried.
4. Present different, role-specific products: a fast, field-focused native ambulance app and a hospital-oriented desktop inbox.
5. Measure delivery rate and recovery time across controlled test conditions.

## Three-minute demo
1. Open the hospital console and point out the empty inbox and metrics.
2. In the iOS app, send a CRITICAL fictional emergency alert. Show it appear in the hospital console and transition to Delivered in Outbox.
3. Turn on simulated outage. Send a vitals update; explain that it is saved locally and no delivery is claimed.
4. Turn off outage and retry. Show the message arrive exactly once.
5. Explain the ACK-after-commit and stable-ID idempotency design. State clearly that relay mode is simulated and no actual MANET is implemented.

## Experiment table template
| Trial | Scenario | Generated | Received unique | Delivery rate | Mean delay (ms) | Recovery time (s) | Notes |
|---|---|---:|---:|---:|---:|---:|---|
| 1 | Stable Wi-Fi | | | | | | |
| 2 | App-level outage 15 s | | | | | | |
| 3 | Server unavailable then restored | | | | | | |
| 4 | Duplicate POST test | | | | | | |

Run multiple trials per scenario, keep the method consistent, and report actual measurements—not expected or fabricated values.

## Discussion questions
- Why does TCP reliability not itself guarantee delivery across application restarts or long disconnections?
- What does the application ACK prove, and what does it not prove?
- Why are stable IDs and idempotent handling necessary when retrying?
- How would a real store-and-forward relay be implemented and tested?
- What security controls would be required before handling real patient information?
