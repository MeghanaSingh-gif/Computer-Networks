"""RescueLink edge gateway: HTTP relay with a durable queue for ambulance messages.
Standard library only. Educational prototype; not for clinical use.
"""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
from urllib.parse import urlsplit
from pathlib import Path
import sqlite3, os, json, threading, time

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.environ.get('RESCUELINK_EDGE_DB', ROOT / 'edge_queue.sqlite3'))
UPSTREAM = os.environ.get('HOSPITAL_URL', 'http://127.0.0.1:8000').rstrip('/')

def db():
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.execute('PRAGMA journal_mode=WAL')
    con.execute('''CREATE TABLE IF NOT EXISTS queue (
        id TEXT PRIMARY KEY, path TEXT NOT NULL, body BLOB NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, attempts INTEGER NOT NULL DEFAULT 0,
        last_error TEXT NOT NULL DEFAULT '')''')
    return con

def try_forward(path, method, body, headers=None, timeout=3):
    headers = dict(headers or {})
    headers.pop('Host', None)
    req = Request(UPSTREAM + path, data=body if method in ('POST','PUT','PATCH') else None,
                  headers=headers, method=method)
    with urlopen(req, timeout=timeout) as resp:
        return resp.status, resp.read(), resp.headers.get('Content-Type', 'application/json; charset=utf-8')

def queue_message(path, body):
    data = json.loads(body.decode('utf-8') or '{}')
    ident = str(data.get('id') or '')
    if not ident:
        raise ValueError('Queued messages must include an id')
    con = db()
    try:
        con.execute('INSERT OR IGNORE INTO queue(id,path,body) VALUES(?,?,?)', (ident, path, body))
        con.commit()
    finally: con.close()

def flush_queue_once():
    con = db()
    try:
        rows = con.execute('SELECT id,path,body FROM queue ORDER BY created_at LIMIT 100').fetchall()
    finally: con.close()
    for ident, path, body in rows:
        try:
            status, _, _ = try_forward(path, 'POST', body, {'Content-Type':'application/json'}, timeout=3)
            if 200 <= status < 300:
                con = db()
                try: con.execute('DELETE FROM queue WHERE id=?', (ident,)); con.commit()
                finally: con.close()
            else:
                con = db()
                try: con.execute('UPDATE queue SET attempts=attempts+1,last_error=? WHERE id=?', (f'HTTP {status}', ident)); con.commit()
                finally: con.close()
        except Exception as exc:
            con = db()
            try: con.execute('UPDATE queue SET attempts=attempts+1,last_error=? WHERE id=?', (str(exc)[:300], ident)); con.commit()
            finally: con.close()

def retry_worker():
    while True:
        flush_queue_once()
        time.sleep(3)

class GatewayHandler(BaseHTTPRequestHandler):
    server_version = 'RescueLinkEdge/1.0'
    def log_message(self, fmt, *args): print('[EDGE %s] %s' % (self.log_date_time_string(), fmt % args))
    def send_bytes(self, status, body, content_type='application/json; charset=utf-8'):
        self.send_response(status); self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body))); self.send_header('Access-Control-Allow-Origin','*')
        self.send_header('Access-Control-Allow-Headers','Content-Type'); self.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS')
        self.end_headers(); self.wfile.write(body)
    def do_OPTIONS(self):
        self.send_response(204); self.send_header('Access-Control-Allow-Origin','*')
        self.send_header('Access-Control-Allow-Headers','Content-Type'); self.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS'); self.end_headers()
    def handle_proxy(self):
        # The gateway has its own identity/health endpoint. Other paths are
        # proxied to the hospital service, including /api/* and /hospital.
        route = urlsplit(self.path).path
        if self.command == 'GET' and route in ('/', '/health', '/api/health'):
            payload = {
                'service': 'RescueLink Edge Gateway',
                'status': 'ok',
                'upstream': UPSTREAM,
                'message': 'Gateway is running. API requests are relayed to the hospital server.',
                'demoOnly': True
            }
            raw = json.dumps(payload).encode('utf-8')
            return self.send_bytes(200, raw)
        body = b''
        if self.command in ('POST','PUT','PATCH'):
            length = int(self.headers.get('Content-Length','0'))
            if length > 1_000_000: return self.send_bytes(413, b'{"error":"Payload too large"}')
            body = self.rfile.read(length)
        path = self.path
        if self.command == 'POST' and urlsplit(path).path == '/api/messages':
            try:
                status, response, ctype = try_forward(path, 'POST', body, {'Content-Type':self.headers.get('Content-Type','application/json')}, timeout=3)
                return self.send_bytes(status, response, ctype)
            except Exception as exc:
                try: queue_message(path, body)
                except Exception as queue_exc:
                    return self.send_bytes(400, json.dumps({'error':str(queue_exc)}).encode())
                # 503 keeps the phone's own outbox pending; the gateway independently retries its durable copy.
                return self.send_bytes(503, json.dumps({'error':'Upstream unavailable; saved at edge gateway; phone should retry','gatewayQueued':True}).encode())
        try:
            status, response, ctype = try_forward(path, self.command, body,
                {'Content-Type':self.headers.get('Content-Type','application/json')}, timeout=4)
            return self.send_bytes(status, response, ctype)
        except HTTPError as exc:
            return self.send_bytes(exc.code, exc.read(), exc.headers.get('Content-Type','application/json; charset=utf-8'))
        except Exception as exc:
            return self.send_bytes(503, json.dumps({'error':'Hospital server unreachable through gateway','detail':str(exc)[:200]}).encode())
    do_GET = handle_proxy
    do_POST = handle_proxy

def run_gateway(host=None, port=None, upstream=None, background_worker=True):
    global UPSTREAM
    if upstream: UPSTREAM = upstream.rstrip('/')
    host = host or os.environ.get('GATEWAY_HOST','0.0.0.0')
    port = int(port or os.environ.get('GATEWAY_PORT','5001'))
    if background_worker:
        threading.Thread(target=retry_worker, daemon=True).start()
    server = ThreadingHTTPServer((host, port), GatewayHandler)
    print(f'RescueLink edge gateway: http://127.0.0.1:{port} -> {UPSTREAM}')
    server.serve_forever()

if __name__ == '__main__':
    run_gateway()
