"""RescueLink v1 demo backend: durable messages, explicit review events, and two-way replies.
Uses Python standard library only. Demo only; not for clinical use.
"""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from datetime import datetime, timezone
import sqlite3, os, json

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.environ.get('RESCUELINK_DB', ROOT / 'resuelink.sqlite3'))
HOSPITAL = ROOT / 'hospital'
SCHEMA = '''
CREATE TABLE IF NOT EXISTS messages (
 id TEXT PRIMARY KEY, kind TEXT NOT NULL, priority TEXT NOT NULL,
 ambulance_id TEXT NOT NULL, patient_ref TEXT, payload TEXT NOT NULL,
 created_at TEXT NOT NULL, received_at TEXT NOT NULL,
 client_sent_at TEXT, client_latency_ms REAL
);
CREATE TABLE IF NOT EXISTS reviews (
 id TEXT PRIMARY KEY, message_id TEXT NOT NULL UNIQUE, reviewer_id TEXT NOT NULL,
 reviewed_at TEXT NOT NULL, note TEXT NOT NULL DEFAULT '',
 FOREIGN KEY(message_id) REFERENCES messages(id)
);
CREATE TABLE IF NOT EXISTS responses (
 id TEXT PRIMARY KEY, message_id TEXT NOT NULL, ambulance_id TEXT NOT NULL,
 patient_ref TEXT, response_type TEXT NOT NULL, status TEXT NOT NULL,
 note TEXT NOT NULL, created_at TEXT NOT NULL,
 received_by_ambulance_at TEXT, sender_role TEXT NOT NULL DEFAULT 'HOSPITAL'
);
'''
def utcnow(): return datetime.now(timezone.utc).isoformat(timespec='milliseconds')
def connect_db():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA foreign_keys=ON')
    conn.executescript(SCHEMA)
    # Safe additive migration for databases created by earlier demo versions.
    cols = {r['name'] for r in conn.execute('PRAGMA table_info(responses)').fetchall()}
    if 'received_by_ambulance_at' not in cols:
        conn.execute('ALTER TABLE responses ADD COLUMN received_by_ambulance_at TEXT')
    if 'sender_role' not in cols:
        conn.execute("ALTER TABLE responses ADD COLUMN sender_role TEXT NOT NULL DEFAULT 'HOSPITAL'")
    return conn

def message_dict(r, review=None):
    return {'id':r['id'],'kind':r['kind'],'priority':r['priority'],'ambulanceId':r['ambulance_id'],
      'patientRef':r['patient_ref'],'payload':json.loads(r['payload']),'createdAt':r['created_at'],
      'receivedAt':r['received_at'],'clientSentAt':r['client_sent_at'],'clientLatencyMs':r['client_latency_ms'],
      'reviewStatus':'REVIEWED' if review else 'AWAITING_REVIEW',
      'reviewedAt':review['reviewed_at'] if review else None,'reviewerId':review['reviewer_id'] if review else None}
def response_dict(r):
    return {'id':r['id'],'messageId':r['message_id'],'ambulanceId':r['ambulance_id'],'patientRef':r['patient_ref'],
      'responseType':r['response_type'],'status':r['status'],'note':r['note'],'createdAt':r['created_at'],
      'receivedByAmbulanceAt':r['received_by_ambulance_at'],'senderRole':r['sender_role'] if 'sender_role' in r.keys() else 'HOSPITAL'}

class Handler(BaseHTTPRequestHandler):
    server_version = 'RescueLink/1.0'
    def log_message(self, fmt, *args): print('[%s] %s' % (self.log_date_time_string(), fmt % args))
    def send_json(self, status, body):
        raw = json.dumps(body).encode()
        self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(raw))); self.send_header('Access-Control-Allow-Origin','*')
        self.send_header('Access-Control-Allow-Headers','Content-Type'); self.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS')
        self.end_headers(); self.wfile.write(raw)
    def do_OPTIONS(self):
        self.send_response(204); self.send_header('Access-Control-Allow-Origin','*')
        self.send_header('Access-Control-Allow-Headers','Content-Type'); self.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS'); self.end_headers()
    def body(self):
        length = int(self.headers.get('Content-Length','0'))
        if length > 1_000_000: raise OverflowError()
        return json.loads(self.rfile.read(length) or b'{}')
    def do_GET(self):
        parsed = urlparse(self.path); path = parsed.path; qs = parse_qs(parsed.query)
        if path == '/api/health':
            return self.send_json(200, {'status':'ok','service':'RescueLink','time':utcnow(),'transport':'HTTP over TCP/IP','database':'SQLite','demoOnly':True})
        if path == '/api/messages':
            priority = qs.get('priority',['ALL'])[0].upper()
            try: limit = min(max(int(qs.get('limit',['200'])[0]),1),500)
            except ValueError: limit = 200
            conn=connect_db()
            try:
                where = "WHERE m.priority=?" if priority in ('CRITICAL','HIGH','NORMAL') else ''
                args = [priority,limit] if where else [limit]
                rows=conn.execute(f'''SELECT m.*,r.id review_id,r.reviewer_id,r.reviewed_at FROM messages m
                  LEFT JOIN reviews r ON r.message_id=m.id {where} ORDER BY m.received_at DESC LIMIT ?''',args).fetchall()
                items=[]
                for row in rows:
                    review = {'reviewed_at':row['reviewed_at'],'reviewer_id':row['reviewer_id']} if row['review_id'] else None
                    items.append(message_dict(row,review))
                return self.send_json(200,{'messages':items})
            finally: conn.close()
        if path == '/api/messages/detail':
            ident=qs.get('id',[''])[0]
            conn=connect_db()
            try:
                row=conn.execute('SELECT * FROM messages WHERE id=?',(ident,)).fetchone()
                if not row: return self.send_json(404,{'error':'Message not found'})
                review=conn.execute('SELECT * FROM reviews WHERE message_id=?',(ident,)).fetchone()
                events=conn.execute('SELECT * FROM responses WHERE message_id=? ORDER BY created_at',(ident,)).fetchall()
                return self.send_json(200,{'message':message_dict(row,review),'responses':[response_dict(x) for x in events]})
            finally: conn.close()
        if path == '/api/metrics':
            conn=connect_db()
            try:
                total=conn.execute('SELECT COUNT(*) FROM messages').fetchone()[0]
                critical=conn.execute("SELECT COUNT(*) FROM messages WHERE priority='CRITICAL'").fetchone()[0]
                avg=conn.execute('SELECT AVG(client_latency_ms) FROM messages WHERE client_latency_ms IS NOT NULL').fetchone()[0]
                by_priority={r['priority']:r['n'] for r in conn.execute('SELECT priority,COUNT(*) n FROM messages GROUP BY priority').fetchall()}
                by_kind=[{'kind':r['kind'],'count':r['n']} for r in conn.execute('SELECT kind,COUNT(*) n FROM messages GROUP BY kind ORDER BY n DESC').fetchall()]
                recent=[{'receivedAt':r['received_at'],'priority':r['priority']} for r in conn.execute('SELECT received_at,priority FROM messages ORDER BY received_at DESC LIMIT 40').fetchall()]
                pending=conn.execute('SELECT COUNT(*) FROM messages m LEFT JOIN reviews r ON r.message_id=m.id WHERE r.id IS NULL').fetchone()[0]
                response_count=conn.execute('SELECT COUNT(*) FROM responses').fetchone()[0]
                return self.send_json(200,{'totalReceived':total,'criticalReceived':critical,'awaitingReview':pending,
                  'averageClientLatencyMs':round(avg,1) if avg is not None else None,'byPriority':by_priority,'byKind':by_kind,'recent':recent,'responsesSent':response_count})
            finally: conn.close()
        if path == '/api/responses':
            ambulance=(qs.get('ambulanceId',[''])[0] or '').strip(); case_id=(qs.get('caseId',[''])[0] or '').strip(); conn=connect_db()
            try:
                clauses=[]; args=[]
                if ambulance: clauses.append('ambulance_id=?'); args.append(ambulance)
                if case_id: clauses.append('patient_ref=?'); args.append(case_id)
                where=(' WHERE '+' AND '.join(clauses)) if clauses else ''
                rows=conn.execute('SELECT * FROM responses'+where+' ORDER BY created_at ASC LIMIT 500',args).fetchall()
                return self.send_json(200,{'responses':[response_dict(r) for r in rows]})
            finally: conn.close()
        if path == '/' or path == '/index.html':
            raw=(HOSPITAL/'index.html').read_bytes(); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw); return
        return self.send_json(404,{'error':'Not found'})
    def do_POST(self):
        path=urlparse(self.path).path
        if path not in ('/api/messages','/api/responses','/api/reviews','/api/response-receipts'):
            return self.send_json(404,{'error':'Not found'})
        try: data=self.body()
        except OverflowError: return self.send_json(413,{'error':'Payload too large'})
        except (ValueError,json.JSONDecodeError): return self.send_json(400,{'error':'Invalid JSON'})
        if path == '/api/reviews':
            required=['id','messageId','reviewerId']; missing=[k for k in required if not str(data.get(k,'')).strip()]
            if missing: return self.send_json(400,{'error':'Missing required fields','fields':missing})
            conn=connect_db()
            try:
                if not conn.execute('SELECT 1 FROM messages WHERE id=?',(str(data['messageId']),)).fetchone(): return self.send_json(404,{'error':'Message not found'})
                now=utcnow()
                conn.execute('INSERT OR IGNORE INTO reviews(id,message_id,reviewer_id,reviewed_at,note) VALUES(?,?,?,?,?)',(str(data['id']),str(data['messageId']),str(data['reviewerId']),now,str(data.get('note') or '')))
                conn.commit()
                row=conn.execute('SELECT * FROM reviews WHERE message_id=?',(str(data['messageId']),)).fetchone()
                return self.send_json(200,{'ack':True,'messageId':row['message_id'],'reviewStatus':'REVIEWED','reviewerId':row['reviewer_id'],'reviewedAt':row['reviewed_at']})
            finally: conn.close()
        if path == '/api/response-receipts':
            required=['id','ambulanceId']; missing=[k for k in required if not str(data.get(k,'')).strip()]
            if missing: return self.send_json(400,{'error':'Missing required fields','fields':missing})
            conn=connect_db()
            try:
                now=utcnow(); cur=conn.execute('UPDATE responses SET received_by_ambulance_at=? WHERE id=? AND ambulance_id=?',(now,str(data['id']),str(data['ambulanceId'])))
                if not cur.rowcount: return self.send_json(404,{'error':'Response not found for ambulance'})
                conn.commit(); return self.send_json(200,{'ack':True,'id':str(data['id']),'receivedByAmbulanceAt':now})
            finally: conn.close()
        if path == '/api/responses':
            required=['id','messageId','ambulanceId','responseType','status','note']; missing=[k for k in required if k not in data]
            if missing: return self.send_json(400,{'error':'Missing required fields','fields':missing})
            allowed={'REPLY','CLARIFICATION_REQUEST','PREPARING','READY','NEEDS_INFORMATION','ACKNOWLEDGED','PREPARE_FOR_ARRIVAL','NEED_MORE_INFO','DIVERT_TO_HOSPITAL','AMBULANCE_REPLY','CLARIFICATION_RESPONSE'}
            if data['status'] not in allowed: return self.send_json(400,{'error':'Invalid response status','allowed':sorted(allowed)})
            sender_role=str(data.get('senderRole') or 'HOSPITAL').upper()
            if sender_role not in ('HOSPITAL','AMBULANCE'): return self.send_json(400,{'error':'senderRole must be HOSPITAL or AMBULANCE'})
            conn=connect_db()
            try:
                if not conn.execute('SELECT 1 FROM messages WHERE id=?',(str(data['messageId']),)).fetchone(): return self.send_json(404,{'error':'Related message not found'})
                conn.execute('INSERT OR IGNORE INTO responses (id,message_id,ambulance_id,patient_ref,response_type,status,note,created_at,sender_role) VALUES (?,?,?,?,?,?,?,?,?)',
                  (str(data['id']),str(data['messageId']),str(data['ambulanceId']),str(data.get('patientRef') or ''),str(data['responseType']),str(data['status']),str(data['note']),utcnow(),sender_role))
                conn.commit(); row=conn.execute('SELECT * FROM responses WHERE id=?',(str(data['id']),)).fetchone()
                return self.send_json(200,{'ack':True,'response':response_dict(row)})
            finally: conn.close()
        required=['id','kind','priority','ambulanceId','payload','createdAt']; missing=[k for k in required if k not in data]
        if missing: return self.send_json(400,{'error':'Missing required fields','fields':missing})
        if data['priority'] not in ('CRITICAL','HIGH','NORMAL'): return self.send_json(400,{'error':'priority must be CRITICAL, HIGH, or NORMAL'})
        if not isinstance(data['payload'],dict): return self.send_json(400,{'error':'payload must be an object'})
        received=utcnow(); conn=connect_db()
        try:
            before=conn.total_changes
            conn.execute('''INSERT OR IGNORE INTO messages (id,kind,priority,ambulance_id,patient_ref,payload,created_at,received_at,client_sent_at,client_latency_ms) VALUES (?,?,?,?,?,?,?,?,?,?)''',
              (str(data['id']),str(data['kind']),str(data['priority']),str(data['ambulanceId']),str(data.get('patientRef') or ''),json.dumps(data['payload']),str(data['createdAt']),received,str(data.get('clientSentAt') or ''),data.get('clientLatencyMs')))
            inserted=conn.total_changes>before; conn.commit()
            row=conn.execute('SELECT * FROM messages WHERE id=?',(str(data['id']),)).fetchone()
            return self.send_json(200,{'ack':True,'id':str(data['id']),'status':'received' if inserted else 'duplicate_already_received','receivedAt':row['received_at']})
        finally: conn.close()

def main():
    port=int(os.environ.get('PORT','8000'))
    # One familiar command starts the hospital service and a local edge gateway.
    # On the Raspberry Pi, run edge_gateway.py alone with HOSPITAL_URL set to the remote server.
    from threading import Thread
    from edge_gateway import run_gateway
    hospital_server = ThreadingHTTPServer(('0.0.0.0',port),Handler)
    print(f'RescueLink hospital server: http://127.0.0.1:{port}')
    print(f'RescueLink hospital dashboard: http://127.0.0.1:{port}/')
    print('RescueLink local edge gateway: http://127.0.0.1:5001')
    print('Demo only. Keep this Terminal window open. Press Ctrl+C to stop.')
    Thread(target=hospital_server.serve_forever, daemon=True).start()
    run_gateway(host='0.0.0.0', port=int(os.environ.get('GATEWAY_PORT','5001')), upstream=f'http://127.0.0.1:{port}')
if __name__=='__main__': main()
